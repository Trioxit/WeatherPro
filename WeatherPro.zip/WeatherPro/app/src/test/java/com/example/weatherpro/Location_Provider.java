package com.example.weatherpro;

public class Location_Provider {
}
